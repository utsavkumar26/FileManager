function TodoCtrl($scope) {
  
  $scope.todos = [
    {text:'Use Angular 1.X', done:false},         
    {text: 'Build an app', done:false}
  ];
  
  $scope.getTotalTodos = function () {
    return $scope.todos.length;
  };
  
  
  $scope.addTodo = function () {
    $scope.todos.push({text:$scope.formTodoText, done:false});   //explain about two way binding using ng-model
    $scope.formTodoText = '';
  };
  
    $scope.removeCompleted = function () {
       /* $scope.todos = _.filter($scope.todos , function(todo){

             if(!todo.done);
             return $scope.todos.push(todo);
            });*/
            var pending = $scope.todos;
            $scope.todos = [];
            angular.forEach(pending, function(todo) {
            if (!todo.done) 
              return $scope.todos.push(todo);
        });
        
    };
}

